/****************************************Copyright (c)****************************************************
**                            Jiangsu Acxion Electrical Co., LTD
**
**                                 http://www.acxion.cn
**
**--------------File Info---------------------------------------------------------------------------------
** File name:           MTH02.C
** Last modified Date:  2011-04-02
** Last Version:        V1.0
** Descriptions:        MTH02��������ȡ
**
**--------------------------------------------------------------------------------------------------------
** Created by:         
** Created date:       
** Version:             
** Descriptions:        
**
**--------------------------------------------------------------------------------------------------------
** Modified by:         
** Modified date:       
** Version:             
** Descriptions:        
**
**--------------------------------------------------------------------------------------------------------
** Modified by:        
** Modified date:      
** Version:            
** Descriptions:       
**
** Rechecked by:
*********************************************************************************************************/
#include<reg51.h>
sbit P1_1=P1^1;//������IO
uchar  FLAG;
uchar  U8count,U8temp;
uchar  U8T_data_H,U8T_data_L,U8RH_data_H,U8RH_data_L,U8checkdata;
uchar  U8T_data_H_temp,U8T_data_L_temp,U8RH_data_H_temp,U8RH_data_L_temp,U8checkdata_temp;
uchar  U8comdata;
uint tmp1=0;
uint rh1=0;
bit TFLAG=0;
/******************************************************************************
** Function name:       delay
** Descriptions:        ����ʱ
** input parameters:   ��
** output parameters:   ��
** Returned value:      
******************************************************************************/
void delay(uint t)
{
	uchar ms;
	for(t;t>0;t--)
		for(ms=100;ms>0;ms--) _nop_();				                                                                                                                                                                                                                                   
}
/******************************************************************************
** Function name:       Delay_10us
** Descriptions:        10us����ʱ	�����ݵ�Ƭ����ʱ��Ƶ�ʵ���	  STC11FXXϵ��
** input parameters:   ��
** output parameters:   ��
** Returned value:      
******************************************************************************/
void  Delay_10us(void)
{
  uchar i;
  for(i=20;i>0;i--)
	{
		_nop_();  
	}
}
/******************************************************************************
** Function name:       ReadOneByte
** Descriptions:        ��ȡ1�ֽ�����
** input parameters:   ��
** output parameters:   ��
** Returned value:      
******************************************************************************/
void ReadOneByte(void)
{
	uchar i;
    for(i=0;i<8;i++)	   
	{
		FLAG=2;
	   	while((!P1_1)&&FLAG++);
		Delay_10us();
		Delay_10us();
		Delay_10us();
	  	U8temp=0;
	    if(P1_1)U8temp=1;
		FLAG=2;
		while((P1_1)&&FLAG++);	   		  
	   	if(FLAG==1)break;	//��ʱ������forѭ��	   	 
		U8comdata<<=1;
	   	U8comdata|=U8temp;       
	 }
}  
/******************************************************************************
** Function name:       ReadSensor
** Descriptions:        ��ȡ����������ʪ��
** input parameters:   ��
** output parameters:   tmp1���¶�ֵ������10�������rh1,ʪ��ֵ	TFLAG=0���¶�Ϊ����=1���¶�Ϊ��
** Returned value:      
******************************************************************************/
void ReadSensor(void)
{
       P1_1=0; //��������
	   delay(4);//��ʱ
	   P1_1=1;//��������
	   Delay_10us(); //�ȴ���������Ӧ
	   Delay_10us();
	   Delay_10us();
	   Delay_10us();
	   P1_1=1;	     
	   FLAG=2; 
	   while((!P1_1)&&FLAG++);//�ȴ��ߵ�ƽ����
	   FLAG=2;
	   ReadOneByte();	//��ȡ5��Byte
	   U8RH_data_H_temp=U8comdata;
	   ReadOneByte();
	   U8RH_data_L_temp=U8comdata;
	   ReadOneByte();
	   U8T_data_H_temp=U8comdata;
	   ReadOneByte();
	   U8T_data_L_temp=U8comdata;
	   ReadOneByte();
	   U8checkdata_temp=U8comdata;
	   U8temp=(U8T_data_H_temp+U8T_data_L_temp+U8RH_data_H_temp+U8RH_data_L_temp);//����������ݵ�У���
	   if(U8temp==U8checkdata_temp)//���У����ȷ
	   {
	   	 U8RH_data_H=U8RH_data_H_temp;
	   	 U8RH_data_L=U8RH_data_L_temp;
	   	 U8T_data_H=U8T_data_H_temp;
	   	 U8T_data_L=U8T_data_L_temp;
	   	 U8checkdata=U8checkdata_temp;
		 tmp1=U8T_data_H<<8|U8T_data_L;	
		 rh1=U8RH_data_H<<8|U8RH_data_L;
		 if(tmp1>=400)//�¶�Ϊ��
		 {
		 	tmp1-=400;
			TFLAG=0;	
		 }
		 else //�¶�Ϊ��
		 {
		 	tmp1=400-tmp1;//ת��Ϊ���¶�
			TFLAG=1; //���¶ȷ���λ��λ
		 } 
	   }	   	   	    
} 
